package com.example.football

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.football.MainUIActivity.Companion.PARCELABLE_ITEM_DATA
import org.jetbrains.anko.*
import org.jetbrains.anko.recyclerview.v7.recyclerView

class MainActivity : AppCompatActivity(){
    companion object{
        public  val PARCELABLE_ITEM_DATA = "item data"
    }
    var  items: MutableList<DataClub> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initData()
        MainActivityUI(items).setContentView(this)
    }

        inner class MainActivityUI(val items: List<DataClub>) : AnkoComponent<MainActivity> {
        override fun createView(ui: AnkoContext<MainActivity>) = with(ui) {
            verticalLayout {
                lparams(matchParent, wrapContent)

                recyclerView {
                    layoutManager = LinearLayoutManager(context)
                    addItemDecoration(DividerItemDecoration(context, 1))
                    adapter = ClubAdapter(items) {
                        startActivity<DetailClubActivity>(PARCELABLE_ITEM_DATA to it)
                    }
                }
            }
        }
    }

    private fun initData(){
        val name = resources.getStringArray(R.array.club_name)
        val image = resources.obtainTypedArray(R.array.club_image)
        val description = resources.getStringArray(R.array.club_desc)
        items.clear()
        for (i in name.indices){
            items.add(DataClub(image.getResourceId(i, 0)
            , name[i], description[i]))
        }
        image.recycle()
    }
}
